
public class Staff extends User {
	public Staff(String userID, String name, String password, String dateOfBirth, int phoneNumber, String email){
		super( userID, name , password , dateOfBirth , phoneNumber , email);
	}
		public String getID(){
			super.getID();
		}
		public void setID(){
			super.setID();
		}
		public void cancelCustomerOrder(){
			
		}
		public void undoCustomerSelection(){
				
		}
}
